import os

# ========== 配置项 ==========
# 文件所在的目录路径（示例：当前目录，可改为绝对路径如 "D:/your_folder/"）
directory = "./"
# ============================

# 遍历目录下所有文件
for filename in os.listdir(directory):
    # 筛选：只处理 .pkl 文件，且文件名包含 "pfsp_instance_0.4f"
    if filename.endswith(".pkl") and "pfsp_instance_0.4f" in filename:
        # 生成新文件名（替换 "0.4f" → "0.2f"）
        new_filename = filename.replace("0.4f", "0.2f")
        # 拼接原文件和新文件的完整路径
        old_path = os.path.join(directory, filename)
        new_path = os.path.join(directory, new_filename)
        # 执行重命名
        os.rename(old_path, new_path)
        print(f"已重命名: {filename} → {new_filename}")